Rev 1.0 - Miguel Morales 
October 2009

To successfully compile the project, create a path variable that points to the SimpliiciTI root folder. 

Windows > Preferences > General > Workspace > Linked Resources > New...

Call the new linked resource:  DEV_ROOT_EXPF543x_110
Point to the folder: 		~\SimpliciTI-CCS-1.1.0-F543x 
