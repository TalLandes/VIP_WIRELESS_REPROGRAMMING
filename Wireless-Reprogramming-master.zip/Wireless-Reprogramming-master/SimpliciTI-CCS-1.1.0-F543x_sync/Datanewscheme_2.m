% read data
f = fopen('acceloDataTEST0618_audio2_66.data', 'rt');

% data1 is the orignial data from the packet
% data2 is the orignial data with their middle point shifted to 0 (by default, 8 conversion bits and 6000 sampling rate)
% data3 is the time shift between the clocks of different motes (doesn't actually use it, for future analysis)
% data4 is the real time of the orignial data (according to RTC module, the value should increment by 1 every 1/32768 sec)

data1=[];
data2=[];
data3=[];
data4=[];

data = fscanf(f,'%d',87);

seq = data(2);
j=1;

roll = seq;
seqs = [];
count =1;
line =1;
legi = 1;
null = 0;

while ~feof(f)
%while line < 67
    if legi == 1        
    datanew = fscanf(f,'%d',87);
    end

    roll = roll+1;
    seq = mod(seq+1,256);
    
    if roll > 255
        seq = seq+1;
        roll=seq;
    end
    %seq
% [data(6) seq line]

    if length(datanew) > 1
        %seq
        
        if datanew(2) == seq
            if null == 1 % last packet lost
                for i=16:1:length(data)-1
                    data2(j) = 0;
                    data3(j) = timedrift;
                    data4(j) = timeold+round((i-16)/(5.46)); % 5.46 = 1/6000(Hz)*32768(Hz)
                    j=j+1;
                end
            else % retrieve last packet's data
                % time difference between when first sample in the packet was gathered and the packet was successfully transmitted
                timedrift = (data(4)*16777216+data(5)*65536+data(6)*256+data(7)) - (datanew(12)*16777216+datanew(13)*65536+datanew(14)*256+datanew(15));                
                timeold = timedrift + (data(8)*16777216+data(9)*65536+data(10)*256+data(11));
                for i=16:1:length(data)-1
                    data1(j) = data(i);
                    data2(j) = data1(j)-128;
                    data3(j) = timedrift;
                    data4(j) = timeold+round((i-16)*(5.46));
                    j=j+1;
                end
            end
            timeold=data4(j-1);
            data = datanew;
            legi = 1;
            null = 0;
        else
            count=count+1 % number of packet-losses
            line;
            timeold;
            if legi == 1 % current packet is lost but last packet is not, so retrieve last packet's data through last computed timedrift
                timeold = timedrift + (data(8)*16777216+data(9)*65536+data(10)*256+data(11));
                for i=16:1:length(data)-1
                    data1(j) = data(i);
                    data2(j) = data1(j)-128;
                    data3(j) = timedrift;
                    data4(j) = timeold+round((i-16)*(5.46));
                    j=j+1;
                end                               
            else % in the middle of severe packet-lossed
                for i=16:1:length(data)-1
                    data2(j) = 0;
                    data3(j) = timedrift;
                    data4(j) = timeold+round((i-16)/(5.46));
                    j=j+1;
                end
            end
            timeold = data4(j-1);
            legi = 0;
            null = 1;
        end
 
    end
line = line +1;
end

TIME_AMPLITUDE=[];
TIME=[];

% The following section is to create the dataset with the index of actually
% clock value

for i=1:length(data4)-1
    TIME_AMPLITUDE(data4(i))=data2(i);
    TIME_AMPLITUDE(data4(i+1))=data2(i+1);
    if(data4(i+1)-data4(i)+1)>2
        TIME_AMPLITUDE((data4(i)+1):(data4(i+1)-1))=linspace(0,0,data4(i+1)-data4(i)+1-2);
    end
end

TIME66=TIME;
DataTEST_32768_66 = TIME_AMPLITUDE;
figure
n=[1:length(TIME_AMPLITUDE)];

plot(n,TIME_AMPLITUDE,'r');
grid on
