clear all;
datainput=fopen('acceloDataTEST0618_audio2.data','rt');
dataoutputED66Y=fopen('acceloDataTEST0618_audio2_66.data','wt');
dataoutputED88Y=fopen('acceloDataTEST0618_audio2_88.data','wt');

F=[];
O=[];
%O=fscanf(datainput,'%d',1);
while ~feof(datainput)
    F=transpose(fscanf(datainput,'%d',87));
    if length(F)==87 
        if F(1)==102 %for ED#66
                fprintf(dataoutputED66Y,'%d\t',F');
                fprintf(dataoutputED66Y,'\r\n');
        else
            if F(1)==136 %for ED#88
                    fprintf(dataoutputED88Y,'%d\t',F');
                    fprintf(dataoutputED88Y,'\r\n');
            end
        end       
    end
end
fclose(datainput);
fclose(dataoutputED66Y);
fclose(dataoutputED88Y);
