/*----------------------------------------------------------------------------

 *  Demo Application for SimpliciTI
 *
 *  L. Friedman
 *  Texas Instruments, Inc.
 *---------------------------------------------------------------------------- */

/**********************************************************************************************
  Copyright 2007-2008 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights granted under
  the terms of a software license agreement between the user who downloaded the software,
  his/her employer (which must be your employer) and Texas Instruments Incorporated (the
  "License"). You may not use this Software unless you agree to abide by the terms of the
  License. The License limits your use, and you acknowledge, that the Software may not be
  modified, copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio frequency
  transceiver, which is integrated into your product. Other than for the foregoing purpose,
  you may not use, reproduce, copy, prepare derivative works of, modify, distribute,
  perform, display or sell this Software and/or its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE PROVIDED �AS IS?
  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY
  WARRANTY OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
  IN NO EVENT SHALL TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL EQUITABLE
  THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY
  INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST
  DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY
  THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
**************************************************************************************************/

/*************************************************************************************************
 * NEW synchronization scheme without using the broadcasting from ACCESS POINT 
 * Added and edited by Ximeng
 * END DEVICE
 *************************************************************************************************
 * Besides the sensed data, End Device will also record 1) the value of clock when the first sample
 * is gathered and 2) the value of clock after last packet is transmitted or denied at three attempts.
 * Thus, every packet transmitted from END DEVICE to ACCESS POINT will contain the value of clock when 
 * the first sample in this packet is gatherd and the value of clock after the LAST packet is finishing
 * transmitting attempts. 
 * 
 * PS: For 2), it would be better if the exact clock value can be recorded RIGHT BEFORE the packet is
 * successfully transmitted. May need to look into the lower layer of the SimpliciTI protocol(NWK, MRFI) 
**************************************************************************************************/
#include <string.h> 

#include "bsp.h"
#include "mrfi.h"
#include "bsp_leds.h"
#include "bsp_buttons.h"
#include "bsp_rtc.h"
#include "nwk_types.h"
#include "nwk_api.h"
#include "nwk_frame.h"
#include "nwk.h"
#include "Accelo.h"

#include "app_remap_led.h"

static void linkTo(void);

void toggleLED(uint8_t);


/* Callback handler */
static uint8_t sCB(linkID_t);

static volatile uint8_t  sPeerFrameSem = 0;
static volatile uint8_t  BcastMsgSem = 0;

static  linkID_t sLinkID1 = 0;

static uint8_t IsSampling = 0;

#define SPIN_ABOUT_A_SECOND   NWK_DELAY(1000)
#define SPIN_ABOUT_A_QUARTER_SECOND   NWK_DELAY(250)

/* How many times to try a Tx and miss an acknowledge before doing a scan */
#define MISSES_IN_A_ROW  2



//////////////////////////////////////////////////
////////////////////////  defintions and variables reataled to teh vibration app
//////////////////////////////////////////////////////


uint8_t BufferX[2400]; // To store the data

#define BytesPerPacket 72; // payload bytes per packet. 
#define WordsPerPacket 36;

uint8_t *msgX;

/* ADDED by XImeng*/
uint8_t TimeX[2400]; // To store the time
volatile uint8_t Transmission = 0; 
volatile uint8_t count = 0;
volatile int16_t offsetvalue = 0;
/**/

//ON/OFF flag
volatile unsigned short AcceloON=0;

////////////////////////////
//////////////////////////////

//#define CLK_PORT_DIR      P11DIR //outputs clocks to testpoints
//#define CLK_PORT_OUT      P11OUT
//#define CLK_PORT_SEL      P11SEL



void main (void)
{
  
BSP_Init();

 setupRTC();//setup Real-time clock for synchronization 
 
  /* If an on-the-fly device address is generated it must be done before the
   * call to SMPL_Init(). If the address is set here the ROM value will not
   * be used. If SMPL_Init() runs before this IOCTL is used the IOCTL call
   * will not take effect. One shot only. The IOCTL call below is conformal.
   */
#ifdef I_WANT_TO_CHANGE_DEFAULT_ROM_DEVICE_ADDRESS_PSEUDO_CODE
  {
    addr_t lAddr;

    createRandomAddress(&lAddr);
    SMPL_Ioctl(IOCTL_OBJ_ADDR, IOCTL_ACT_SET, &lAddr);
  }
#endif /* I_WANT_TO_CHANGE_DEFAULT_ROM_DEVICE_ADDRESS_PSEUDO_CODE */

  /* Keep trying to join (a side effect of successful initialization) until
   * successful. Toggle LEDS to indicate that joining has not occurred.
   */
  while (SMPL_SUCCESS != SMPL_Init(sCB))
  {
    toggleLED(1);
    toggleLED(2);
    SPIN_ABOUT_A_SECOND;
  }

  /* LEDs on solid to indicate successful join. */
  if (!BSP_LED2_IS_ON())
  {
    toggleLED(2);
  }
  if (!BSP_LED1_IS_ON())
  {
    toggleLED(1);
  }

  //CLK_PORT_DIR |= 0x07; outputing the clocks 
  //CLK_PORT_SEL |= 0x07;
  /* Unconditional link to AP which is listening due to successful join. */
  
  //DMAsegments = 0;
  Transmission = 0;
  
  
  linkTo();

  while (1){
 
  }
}



static void linkTo()
{
  uint8_t msg[80];
  uint8_t rec_msg[80];
  addr_t  sAdd;
  uint8_t len;
  bspIState_t intState;
  

  uint8_t payloadSize = BytesPerPacket;
  uint8_t i=0;
  uint8_t z=0;
  uint16_t j=0;
  int16_t offset,offset_msg;
  
 // msg[5] = (uint8_t) BytesPerPacket;
  
  for (j=0;j<2400;j++){ //intialize all buffers to zeros, only one channel is utilized here
    	BufferX[j]=0;
  }    
  
  msg[4]=0;
  msg[5]=0;
  msg[6]=0;
  msg[7]=0;
  
  /* Keep trying to link... */
  while (SMPL_SUCCESS != SMPL_Link(&sLinkID1))
  {
    toggleLED(1);
    toggleLED(2);
    SPIN_ABOUT_A_SECOND;
  }

  /* Turn off LEDs. */
  if (BSP_LED2_IS_ON())
  {
    toggleLED(2);
  }
  if (BSP_LED1_IS_ON())
  {
    toggleLED(1);
  }

  /* sleep until button press... */
  //SMPL_Ioctl( IOCTL_OBJ_RADIO, IOCTL_ACT_RADIO_SLEEP, 0);

SMPL_Ioctl( IOCTL_OBJ_RADIO, IOCTL_ACT_RADIO_AWAKE, 0);
SMPL_Ioctl( IOCTL_OBJ_RADIO, IOCTL_ACT_RADIO_RXON, 0);

 //enable general interrupts
    __bis_SR_register(GIE);
    
    
  while (1)
  {
  	

	if (IsSampling == 1 )
    {              						
	if(Transmission > 0) //gathered data ready to transmitt, no DMA here
	{
			P1OUT|=0x01;					
			i=(i+1)&0x1F;
            offset = i*BytesPerPacket;
			offsetvalue = offset;
			

	        ADC12IFG &= ~(ADC12IFG0); // clear IFG flag
	        ADC12CTL0 |= ADC12ENC;
	        TBCTL |= MC0; // start timer B

			
			msg[0] = TimeX[offset_msg];//the clock's value after the first sample is converted, gathered through interrupt 
			msg[1] = TimeX[offset_msg+1];
			msg[2] = TimeX[offset_msg+2];
			msg[3] = TimeX[offset_msg+3];
				
			//read the data		
			msgX = (uint8_t*)(BufferX + offset_msg);
						 
			// msg[0] = 0x01; //channel x	

			for (j=0;j<payloadSize;j++)
			{
				msg[8+j]=msgX[j];				
			}			
            z=0;	
            
/************************************************************************************************************
* Gather the clock's value after the one packet is successfully transmitted or the value of clock after three 
* unsuccessfully attempts, added by Ximeng
*************************************************************************************************************/			
			for(j=0;j<3;j++){                
	 			if(SMPL_SUCCESS == SMPL_Send(sLinkID1, msg, payloadSize+8)){
                        msg[4] = getRTCNT4();//read the real time clock at this point 
			            msg[5] = getRTCNT3();
			            msg[6] = getRTCNT2();
			            msg[7] = getRTCNT1();
						break;
				}
                z++;
			}
            if (z==3){
                    msg[4] = getRTCNT4();//read the real time clock at this point 
			        msg[5] = getRTCNT3();
			        msg[6] = getRTCNT2();
			        msg[7] = getRTCNT1();
            }
						
	    	offset_msg = i*BytesPerPacket;//set the buffer index for the next "TRANSMISSION" cycle
	    	
	    	BSP_ENTER_CRITICAL_SECTION(intState);
     	        Transmission--;
		    BSP_EXIT_CRITICAL_SECTION(intState);						    
	       }
		    P1OUT&=~(0x01);		   
    }//if(IsSampling)    
    
    if (sPeerFrameSem)
    {
      if (SMPL_SUCCESS == SMPL_Receive_Src(sLinkID1, rec_msg, &len, &sAdd, 0, 0, 0))
        {
          if(rec_msg[0]=='S' && rec_msg[1]=='S' && IsSampling==0 )
          {
          	IsSampling = 1;
          	i=0; //buffer index
            count=0;
          	AccelerometerInit();
          	turnAccOn();
          	
          	offset = i*BytesPerPacket;
          	offset_msg = i*BytesPerPacket;
          	offsetvalue = offset; //Initializating buffer index
			   
		    TBCTL |= MC0;
		  }
                      	
          if(rec_msg[0]=='T' && rec_msg[1]=='S')
          {
          	//terminate sampling
          	IsSampling = 0;
          	TBCTL &= ~MC0; //stop TimerB 
          	turnAccOff();
	
          }      
          //checkChangeChannel();
          BSP_ENTER_CRITICAL_SECTION(intState);
          sPeerFrameSem--;
          BSP_EXIT_CRITICAL_SECTION(intState);
        }
    }
             
/************************************************************************************************************
* NO broadcast messages here since NO sync packets are transmitted from the ACCESS POINT
*************************************************************************************************************/    
    if(BcastMsgSem)
    {   
     if (SMPL_SUCCESS == SMPL_Receive_Src(SMPL_LINKID_USER_UUD, rec_msg, &len, &sAdd, 0, 0, 0))
     {            
      }//smpl_rec
    }//if(BcastMsgSem)
       
  }//while(1)
}


void toggleLED(uint8_t which)
{
  if (1 == which)
  {
    BSP_TOGGLE_LED1();
  }
  else if (2 == which)
  {
    BSP_TOGGLE_LED2();
  }
  return;
}

static uint8_t sCB(linkID_t lid)
{
  if (lid == sLinkID1) // a unicast message has been received
  {
    sPeerFrameSem++;
    return 0;
  }
  else if(lid == SMPL_LINKID_USER_UUD) //a broadcast message has been received 
  {
  	BcastMsgSem++;
  	return 0;
  }
  return 1;
}


// AUDIO INITIALIZATION here, added and edited by Ximeng
void AccelerometerInit(void)
{

  //setup ACCELO power connection
  //ACC_PPORT_SEL &= ~( ACC_X_PIN + ACC_Y_PIN + ACC_Z_PIN); // make P3.4/3.5/3.6 mode "General I/O" 
  //ACC_PPORT_DIR |= ACC_X_PIN + ACC_Y_PIN + ACC_Z_PIN; //Set  P3.4/3.5/3.6 as output
  //ACC_PPORT_OUT |= ACC_X_PIN + ACC_Y_PIN + ACC_Z_PIN; // High voltage turns on
  
  //ACC_PPORT_SEL &= ~( ACC_Y_PIN ); // make P3.4/3.5/3.6 mode "General I/O" 
  //ACC_PPORT_DIR |= ACC_Y_PIN; //Set  P3.4/3.5/3.6 as output
  //ACC_PPORT_OUT |= ACC_Y_PIN; // High voltage turns on
  
    P6OUT = BIT6 ;
    P6DIR |= BIT4;
    P6OUT |= BIT4;
    P6SEL &= ~BIT4;
    //mic signal
    P6OUT &= ~BIT5;
    P6DIR &= ~BIT5;
    P6SEL |= BIT5;
  
  //setup ACCELO data connection
  //ACC_DPORT_SEL |= ACC_X_PIN + ACC_Y_PIN + ACC_Z_PIN; //set as I/O
  //ACC_DPORT_SEL |= ACC_Y_PIN; //set as I/O
  
  //ACC_DPORT_DIR &= ~(ACC_X_PIN);
  //ACC_DPORT_DIR &= ~(ACC_Y_PIN);
  //ACC_DPORT_DIR &= ~(ACC_Z_PIN);

  //ACC_DPORT_OUT &= ~(ACC_X_PIN);
  //ACC_DPORT_OUT &= ~(ACC_Y_PIN);
  //ACC_DPORT_OUT &= ~(ACC_Z_PIN );
       
 
  ADC12CTL0 &= ~ADC12ENC;  
 
  //Setup ADC12   
   //ADC12SHT12 selects 16 cyclye of ADCCLK for t_sample
  ADC12CTL0 = ADC12ON + ADC12SHT0_12;// 
  

  //ADC12SHP : ADC12 triggered by timer
  //ADC12CONSEQ_3: repeated multiple of channels
  // ADC12SSEL_2 : MCLK as ADC12 clk
  //ADC12SHS_3 : TimerB to SHI
  //ADC12CTL1 = ADC12SHP + ADC12CONSEQ_3  + ADC12SHS_3 + ADC12SSEL_0;// + ADC12SSEL_3;
  ADC12CTL1 = ADC12SHP + ADC12CONSEQ_2  + ADC12SHS_3 + ADC12SSEL_3;// + ADC12SSEL_3;  
  
  //ADC12CTL2 = ADC12RES_2;//set ADC resolution to 12 bits/sample
  ADC12CTL2 = ADC12RES_0;//set ADC resolution to 8 bits/sample

  
  //ADC12MCTL0 = ACC_Y_CHANNEL;  //channel 12
  ADC12MCTL0 = ADC12INCH_5| ADC12EOS; //audio channel 5
  ADC12IE = ADC12IE0;
  
  //ADC12MCTL1 = ACC_Y_CHANNEL| ADC12EOS;  //channel 13
  //ADC12MCTL1 = ACC_Y_CHANNEL;
  //ADC12MCTL2 = ACC_Z_CHANNEL| ADC12EOS;  //channel 14
  
  //ACC_PPORT_OUT &= ~( ACC_X_PIN + ACC_Y_PIN + ACC_Z_PIN); // make sure power pin to interface is high (OFF) 
  //ACC_PPORT_OUT &= ~( ACC_Y_PIN ); // make sure power pin to interface is high (OFF) 
  P6OUT &= ~BIT4;
  
  //Disable reference module 
  REFCTL0 &= ~REFMSTR;
  
  // TimerB trigers the ADC sampling by generating a PWM signal 
  // the SMCLK runs at 3.997696 MHz the PWM is 39977 cyclyes ==> 100 samples/sec = sampling rate
 
  TBCTL = TBSSEL_2;   // Use SMCLK as Timer_B source
  TBR = 0;
  //TBCCR0 = 5500;     // Initialize TBCCR0 3000
  //TBCCR0 = 3270;
  //TBCCR0 = 8000;
  TBCCR0 = 2750;  //6000
  //TBCCR0 = 4195;
  //TBCCR0 = 2047;
  //TBCCR1= 5500 - 1000;
  //TBCCR1= 3270 - 1000;
  //TBCCR1= 8000 - 1000;
  TBCCR1 = 2750-1000;
  //TBCCR1 = 4195-100;
  //TBCCR1 = 2047-100;
  
  TBCCTL1 = OUTMOD_7;      

 
  ADC12CTL0 |=  ADC12ENC;//    //Enable and Start conversion
 
                                                               
  __delay_cycles(200000);                     
}

void turnAccOn(void){ 
  
  uint8_t i = 0;

  //ACC_PPORT_OUT |= ACC_X_PIN; //turn power on for each accelerometer  
  P6OUT |= BIT4;
  //ACC_PPORT_OUT |= ACC_Y_PIN;
  //ACC_PPORT_OUT |= ACC_Z_PIN;
  
  
  for(i=0;i<20;i++)
  {
      	__delay_cycles(800000);  //give the accelerometer some time to settle
  }
   

}

void turnAccOff(void){ 
  

  //ACC_PPORT_OUT &= ~ACC_X_PIN; //turn power on for each accelerometer 
  P6OUT &=~BIT4;
  //ACC_PPORT_OUT &= ~ACC_Y_PIN;
  //ACC_PPORT_OUT &= ~ACC_Z_PIN;
   

}


/************************************************************************************************************
* ADC12 Interrupt: In charge of storing data from ADC's memory, added by Ximeng
*************************************************************************************************************/ 
#pragma vector=ADC12_VECTOR
__interrupt void ADC12_ISR(void){
	//P1OUT^=0x01;
    switch (__even_in_range(ADC12IV, ADC12IV_ADC12IFG15))
    {
        case  ADC12IV_ADC12IFG0: // Vector  6:  ADC12IFG0
        // Vector  8:  ADC12IFG1
        if(count==0){ //record the value of clock when the first sample is gathered
        TimeX[offsetvalue]=getRTCNT4();
        TimeX[offsetvalue+1]=getRTCNT3();
        TimeX[offsetvalue+2]=getRTCNT2();
        TimeX[offsetvalue+3]=getRTCNT1();  
        }      
        BufferX[offsetvalue+count]=ADC12MEM0;
        count++;
        if(count==72){ //everytime after 72 samples, a packet is ready to be transmitted from END DEVICE 
             Transmission++; // one transmission awaits
             TBCTL &= ~MC0;
             ADC12CTL0 &= ~ADC12ENC;
             count=0; 
        }
        break;
    }
	ADC12IFG &= ~(ADC12IFG0);
}
